First you will have to copy the various .php and .html
and .txt files to the mystuff directory in your
linux account