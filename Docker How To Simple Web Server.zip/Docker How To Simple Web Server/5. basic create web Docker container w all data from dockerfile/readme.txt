The only difference between this and the original
3. basic create web Docker container from dockerfile
directory is that the dockerfile copies in the web
files. 
First you will have to copy the various .php and .html
and .txt files to the mystuff directory in your
linux account