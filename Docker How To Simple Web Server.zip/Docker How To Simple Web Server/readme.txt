Read and do this in 1, 2, 3,4, 5, 6 order.

Note that this shows how to create an image
then a running container from that image.
Then copy web files into the running
container.

Then export/import the running container.

You can see in the imported running container
how the files that were copied in are included.
However, you lost the metadata from the original
container, and you had to have a way to retrieve/save
the starting command.

Now build a better image that already contains
the web files (using an updated/improved dockerfile).

Then save/load the image.
You get the files but now the metadata is transferred
over with no problems.

Note that the myhack.txt web file will show you
how to do cross site scripting with this example:

Bring up simpleQ.html in a web server (apache, IIS, etc.)

Access simpleQ.html with either Firefox or Edge (Chrome will stop this particular attack)

Copy and paste from myhack.txt into the data input area in simpleQ.html

You will see that data from a totally different web page is downloaded.
